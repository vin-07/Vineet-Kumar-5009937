public class SingletonPatternExample {

    // Logger class implementing Singleton pattern
    public static class Logger {
        // Step 2: Private static instance of Logger class
        private static Logger instance;

        // Step 2: Private constructor to prevent instantiation
        private Logger() {
            // Initialize resources if needed
        }

        // Step 2: Public static method to provide access to the single instance
        public static Logger getInstance() {
            if (instance == null) {
                synchronized (Logger.class) {
                    if (instance == null) {
                        instance = new Logger();
                    }
                }
            }
            return instance;
        }

        // Example logging method
        public void log(String message) {
            System.out.println("Log: " + message);
        }
    }

    // Main class to test the Singleton implementation
    public static void main(String[] args) {
        // Get the first instance of Logger
        Logger logger1 = Logger.getInstance();
        
        // Get another instance of Logger
        Logger logger2 = Logger.getInstance();
        
        // Log messages
        logger1.log("This is the first log message.");
        logger2.log("This is the second log message.");
        
        // Check if both instances are the same
        if (logger1 == logger2) {
            System.out.println("Both logger1 and logger2 refer to the same instance.");
        } else {
            System.out.println("logger1 and logger2 are different instances.");
        }
    }
}
