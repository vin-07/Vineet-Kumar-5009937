public class BuilderPatternExample {

    // Step 2: Define the Product Class
    public static class Computer {
        private String CPU;
        private String RAM;
        private String storage;
        private String graphicsCard;
        private boolean hasBluetooth;
        private boolean hasWiFi;

        // Private constructor to be used by the Builder
        private Computer(Builder builder) {
            this.CPU = builder.CPU;
            this.RAM = builder.RAM;
            this.storage = builder.storage;
            this.graphicsCard = builder.graphicsCard;
            this.hasBluetooth = builder.hasBluetooth;
            this.hasWiFi = builder.hasWiFi;
        }

        @Override
        public String toString() {
            return "Computer{" +
                   "CPU='" + CPU + '\'' +
                   ", RAM='" + RAM + '\'' +
                   ", storage='" + storage + '\'' +
                   ", graphicsCard='" + graphicsCard + '\'' +
                   ", hasBluetooth=" + hasBluetooth +
                   ", hasWiFi=" + hasWiFi +
                   '}';
        }

        // Step 3: Implement the Builder Class
        public static class Builder {
            private String CPU;
            private String RAM;
            private String storage;
            private String graphicsCard;
            private boolean hasBluetooth;
            private boolean hasWiFi;

            public Builder setCPU(String CPU) {
                this.CPU = CPU;
                return this;
            }

            public Builder setRAM(String RAM) {
                this.RAM = RAM;
                return this;
            }

            public Builder setStorage(String storage) {
                this.storage = storage;
                return this;
            }

            public Builder setGraphicsCard(String graphicsCard) {
                this.graphicsCard = graphicsCard;
                return this;
            }

            public Builder setBluetooth(boolean hasBluetooth) {
                this.hasBluetooth = hasBluetooth;
                return this;
            }

            public Builder setWiFi(boolean hasWiFi) {
                this.hasWiFi = hasWiFi;
                return this;
            }

            // Build method to create the Computer instance
            public Computer build() {
                return new Computer(this);
            }
        }
    }

    // Step 5: Test the Builder Implementation
    public static void main(String[] args) {
        // Create a basic Computer configuration
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel i5")
                .setRAM("8GB")
                .setStorage("500GB SSD")
                .build();

        // Create a high-end Computer configuration
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA GTX 3080")
                .setBluetooth(true)
                .setWiFi(true)
                .build();

        // Print the configurations
        System.out.println("Basic Computer: " + basicComputer);
        System.out.println("Gaming Computer: " + gamingComputer);
    }
}
