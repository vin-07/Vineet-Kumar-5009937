public class AdapterPatternExample {

    // Step 2: Define the Target Interface
    public interface PaymentProcessor {
        void processPayment(double amount);
    }

    // Step 3: Implement Adaptee Classes
    public static class PayPalGateway {
        public void makePayment(double amount) {
            System.out.println("Processing payment through PayPal: $" + amount);
        }
    }

    public static class StripeGateway {
        public void executePayment(double amount) {
            System.out.println("Processing payment through Stripe: $" + amount);
        }
    }

    // Step 4: Implement the Adapter Classes
    public static class PayPalAdapter implements PaymentProcessor {
        private PayPalGateway payPalGateway;

        public PayPalAdapter(PayPalGateway payPalGateway) {
            this.payPalGateway = payPalGateway;
        }

        @Override
        public void processPayment(double amount) {
            payPalGateway.makePayment(amount);
        }
    }

    public static class StripeAdapter implements PaymentProcessor {
        private StripeGateway stripeGateway;

        public StripeAdapter(StripeGateway stripeGateway) {
            this.stripeGateway = stripeGateway;
        }

        @Override
        public void processPayment(double amount) {
            stripeGateway.executePayment(amount);
        }
    }

    // Step 5: Test the Adapter Implementation
    public static void main(String[] args) {
        // Create instances of the third-party gateways
        PayPalGateway payPal = new PayPalGateway();
        StripeGateway stripe = new StripeGateway();

        // Create adapters for the gateways
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPal);
        PaymentProcessor stripeProcessor = new StripeAdapter(stripe);

        // Process payments through the adapters
        payPalProcessor.processPayment(100.00);
        stripeProcessor.processPayment(200.00);
    }
}
