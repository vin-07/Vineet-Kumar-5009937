public class DecoratorPatternExample {

    // Step 2: Define Component Interface
    public interface Notifier {
        void send(String message);
    }

    // Step 3: Implement Concrete Component
    public static class EmailNotifier implements Notifier {
        @Override
        public void send(String message) {
            System.out.println("Sending email with message: " + message);
        }
    }

    // Step 4: Implement Decorator Classes
    public abstract static class NotifierDecorator implements Notifier {
        protected Notifier notifier;

        public NotifierDecorator(Notifier notifier) {
            this.notifier = notifier;
        }

        @Override
        public void send(String message) {
            notifier.send(message);
        }
    }

    public static class SMSNotifierDecorator extends NotifierDecorator {
        public SMSNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message);  // Send the base notification (e.g., email)
            sendSMS(message);     // Add SMS notification functionality
        }

        private void sendSMS(String message) {
            System.out.println("Sending SMS with message: " + message);
        }
    }

    public static class SlackNotifierDecorator extends NotifierDecorator {
        public SlackNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message);  // Send the base notification (e.g., email)
            sendSlackMessage(message); // Add Slack notification functionality
        }

        private void sendSlackMessage(String message) {
            System.out.println("Sending Slack message with message: " + message);
        }
    }

    // Step 5: Test the Decorator Implementation
    public static void main(String[] args) {
        // Create a base EmailNotifier
        Notifier emailNotifier = new EmailNotifier();

        // Decorate it with SMS functionality
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);

        // Decorate it with Slack functionality
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        // Send notifications
        slackNotifier.send("Hello, World!");
    }
}
