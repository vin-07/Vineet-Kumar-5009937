public class ProxyPatternExample {

    // Step 2: Define Subject Interface
    public interface Image {
        void display();
    }

    // Step 3: Implement Real Subject Class
    public static class RealImage implements Image {
        private String fileName;

        public RealImage(String fileName) {
            this.fileName = fileName;
            loadImageFromServer();
        }

        private void loadImageFromServer() {
            System.out.println("Loading image: " + fileName);
            // Simulate loading image from a remote server
        }

        @Override
        public void display() {
            System.out.println("Displaying image: " + fileName);
        }
    }

    // Step 4: Implement Proxy Class
    public static class ProxyImage implements Image {
        private RealImage realImage;
        private String fileName;
        private boolean isLoaded;

        public ProxyImage(String fileName) {
            this.fileName = fileName;
            this.isLoaded = false;
        }

        @Override
        public void display() {
            if (!isLoaded) {
                realImage = new RealImage(fileName);
                isLoaded = true;
            }
            realImage.display();
        }
    }

    // Step 5: Test the Proxy Implementation
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // Load and display image 1
        image1.display(); // Image is loaded and displayed
        image1.display(); // Image is already cached, just displayed

        // Load and display image 2
        image2.display(); // Image is loaded and displayed
    }
}
